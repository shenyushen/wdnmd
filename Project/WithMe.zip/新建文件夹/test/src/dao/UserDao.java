package dao;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;



/**
 * �������û������в���
 * @author lww
 *
 */
public class UserDao {
	
	public ResultSet queryDate(String sql) throws ClassNotFoundException, SQLException {
		Connection conn = DBManager.getInstance().getConnection();
		Statement stmt = conn.createStatement();
		// ִ�в�ѯ
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
	public int updateDate(String sql) throws ClassNotFoundException, SQLException {
		Connection conn = DBManager.getInstance().getConnection();
		Statement stmt = conn.createStatement();
		// ִ�в�ѯ
		int rs = stmt.executeUpdate(sql);
		if (rs > 0) return 1;
		else return 0;
	}
	public int deleteDate(String sql) throws ClassNotFoundException, SQLException {
		Connection conn = DBManager.getInstance().getConnection();
		Statement stmt = conn.createStatement();
		// ִ�в�ѯ
		int rs = stmt.executeUpdate(sql);
		if (rs > 0) return 1;
		else return 0;
	}
	public int addData(String sql) throws ClassNotFoundException, SQLException {
		Connection conn = DBManager.getInstance().getConnection();
		Statement stmt = conn.createStatement();
		// ִ�в�ѯ
		int rs = stmt.executeUpdate(sql);
		if (rs > 0) return 1;
		else return 0;
	}
	public void lookmessage(PrintWriter s) throws ClassNotFoundException, SQLException {
		
		ResultSet rs=null;
		try {
			Connection conn = DBManager.getInstance().getConnection();
			Statement a = conn.createStatement();
			rs = a.executeQuery("select user.user_image,community.* FROM user,community where community.account=user.account");
			while(rs.next()) {
				String cN =rs.getString("user_image")+" "+rs.getString("account")+" "+rs.getString("time")+" "+rs.getString("text")+" "+rs.getString("id")+" "+rs.getString("image");
				s.println(cN);
			}
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public void lookdetailsmessage(PrintWriter s,HttpServletRequest request ) {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		try {
			Connection conn = DBManager.getInstance().getConnection();
			Statement a = conn.createStatement();
			rs = a.executeQuery("select user.user_image,comment.* FROM user,comment where comment.account=user.account and id='"+request.getParameter("id").trim()+"'");
			while(rs.next()) {
				String cN =rs.getString("user_image")+" "+rs.getString("account")+" "+rs.getString("text")+" "+rs.getString("time");
				s.println(cN);
			}
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public void addcomment(PrintWriter s, HttpServletRequest request) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			Connection conn = DBManager.getInstance().getConnection();
			Statement a = conn.createStatement();
			java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd-HH:mm:ss"); //这个是设置时间的格式;
			java.util.Date currentTime = new java.util.Date();//得到当前系统时间
			String str_date1 = formatter.format(currentTime); //将日期时间格式化
			rs = a.executeUpdate("INSERT into COMMent VALUES("+request.getParameter("id")+",'"+request.getParameter("account")+"','"+request.getParameter("text")+"','"+str_date1+"')");
				s.println(rs);
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public void lookonesmessage(PrintWriter s, HttpServletRequest request) {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		try {
			Connection conn = DBManager.getInstance().getConnection();
			Statement a = conn.createStatement();
			rs = a.executeQuery("select * FROM user where account='"+request.getParameter("account").trim()+"'");
			while(rs.next()) {
				String cN =rs.getString("user_image")+" "+rs.getString("account")+" "+rs.getString("name")+" "+rs.getString("sex")+" "+rs.getString("birthday")+" "+rs.getString("hobby")+" "+rs.getString("Personalsignature");
				s.println(cN);
			}
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public void uploadimage(PrintWriter s, HttpServletRequest request) {
		// TODO Auto-generated method stub
		int rs=0;
		ResultSet rs1=null;
		ResultSet rs2=null;
		String cN="";
		String cN1="";
		try {
			Connection conn2 = DBManager.getInstance().getConnection();
			Statement a2 = conn2.createStatement();
			Connection conn1 = DBManager.getInstance().getConnection();
			Statement a1 = conn1.createStatement();
			rs1 = a1.executeQuery("SELECT MAX(id) as id FROM community");
			while(rs1.next()) {
				cN =rs1.getString("id");
				if(cN==null){
					cN="0";
				}
				System.out.println(cN);
			}
			int i=Integer.valueOf(cN)+1;
			cN=i+"";
			Connection conn = DBManager.getInstance().getConnection();
			Statement a = conn.createStatement();
			java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd-HH:mm:ss"); //这个是设置时间的格式;
			java.util.Date currentTime = new java.util.Date();//得到当前系统时间
			String str_date1 = formatter.format(currentTime); //将日期时间格式化
			rs = a.executeUpdate("INSERT into community VALUES('"+request.getParameter("account")+"','"+str_date1+"','"+request.getParameter("text")+"','"+cN+"','"+request.getParameter("image")+"')");
			rs2 = a2.executeQuery("SELECT * FROM community,user where community.account=user.account and community.time='"+str_date1+"'and user.account='"+request.getParameter("account")+"'");
			while(rs2.next()) {
				cN1 =rs2.getString("account")+" "+rs2.getString("user_image")+" "+rs2.getString("id")+" ";
			}
			s.println(rs+" "+cN1+str_date1);
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
}
