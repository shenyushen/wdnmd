package t;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

/**
* @Description: ��ѯdiary�е�����
* @author by SIONON
* @date 2019/12/1
* @version V1.0
*/
@WebServlet("/viewdiary")
public class viewdiary extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewdiary() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				request.setCharacterEncoding("utf-8");
				response.setContentType("text/html;charset=utf-8");
				String account = request.getParameter("a");
				try {
					UserDao a = new UserDao();
				ResultSet rs = a.queryDate("select * from diary where account = '"+account+"'");
				int count = 0;
				PrintWriter writer = response.getWriter();
				SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy-M-d");
				writer.write("[");
					while(rs.next()) {
						if (count != 0)
							writer.write(",");
						Date test = rs.getDate(2);
						String time4 = sdf4.format(test);
						writer.write("{");
						writer.write("\"account\":");
						writer.write("\""+rs.getString(1)+"\""+",");
						writer.write("\"time\":");
						writer.write("\""+time4+"\""+",");
						writer.write("\"text\":");
						writer.write("\""+rs.getString(3)+"\"");
						writer.write("}");
						count=1;
					}
				writer.write("]");
				
				System.out.println("51151336");
				} catch (SQLException | ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
