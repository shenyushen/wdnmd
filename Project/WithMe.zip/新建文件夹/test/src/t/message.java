package t;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import dao.UserDao;

/**
 * Servlet implementation class message
 */
@WebServlet("/message")
public class message extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public message() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  response.setContentType("text/html;charset=utf-8");
		  request.setCharacterEncoding("utf-8");
		  PrintWriter s=response.getWriter();
		  String que=request.getParameter("que").trim();
		  if(que!=null && que.equals("lookmessage")) 
			  { 
				  UserDao d=new UserDao();
				  try { 
					  d.lookmessage(s); 
				  } catch(ClassNotFoundException | SQLException e) { 
					  // TODO Auto-generated catch block 
					  	e.printStackTrace(); 
				  } 
		  }
		  if(que!=null && que.equals("lookdetailsmessage")) 
		  { 
			  UserDao d=new UserDao();
			  d.lookdetailsmessage(s,request); 
		  }
		  if(que!=null && que.equals("addcomment")) 
		  { 
			  UserDao d=new UserDao();
			  d.addcomment(s,request); 
		  }
		  if(que!=null && que.equals("lookonesmessage")) 
		  { 
			  UserDao d=new UserDao();
			  d.lookonesmessage(s,request); 
		  }
		  if(que!=null && que.equals("upload")) 
		  { 
			  this.doPost(request, response);
		  }
		  if(que!=null && que.equals("uploadimage")) 
		  { 
			  UserDao d=new UserDao();
			  d.uploadimage(s,request); 
		  }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String realPath = "F:\\java\\workshop1\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp3\\wtpwebapps\\test\\upload";
		MultipartRequest mr = new MultipartRequest(request, realPath,"utf-8");
		response.getWriter().println("upload OK");
		
		
		
		
		
		
		
		
	}

}
