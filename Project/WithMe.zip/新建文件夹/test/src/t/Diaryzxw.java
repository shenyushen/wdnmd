package t;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

/**
 * Servlet implementation class Diaryzxw
 */
@WebServlet("/Diaryzxw")
public class Diaryzxw extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Diaryzxw() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String account = request.getParameter("account");
	
		UserDao dao = new UserDao();	
		
		
		
		try {
			ResultSet rs = dao.queryDate("select * from diary where account = '"+account+"'order by time asc");
			ResultSet rs1 = dao.queryDate("select * from diary where account = '"+account+"'order by time asc");
			int count = 0;
	
			PrintWriter writer = response.getWriter();
			SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Timestamp timestamp = new Timestamp((new Date()).getTime());
			int i = 0;
			while(rs1.next()) {
				Timestamp time = rs1.getTimestamp(2);
				if (time.before(timestamp)) {
		            i++;
		        }
			}

			writer.write("[");
				while(rs.next()) {
					if (count != 0)
						writer.write(",");
					Timestamp time = rs.getTimestamp(2);
					String time4 = sdf4.format(time);
					writer.write("{");
					writer.write("\"time\":");
					writer.write("\""+time4+"\""+",");
					writer.write("\"abc\":");
					writer.write("\""+i+"\""+",");
					writer.write("\"text\":");
					writer.write("\""+rs.getString(3)+"\"");
					writer.write("}");
					count=1;
				}
			writer.write("]");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
