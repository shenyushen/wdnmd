package t;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import dao.UserDao;

@WebServlet("/uptou")
public class uptou extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uptou() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		System.out.println("sss");
		String account=request.getParameter("account");
		System.out.println("ssssss "+account);
		String Image=request.getParameter("Image");
		UserDao user=new UserDao();
		try {
			user.updateDate("update user set user_image='"+Image+"'where account='"+account+"'");
			System.out.println("update user set user_image='"+Image+"'where account='"+account+"'");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String realPath = "F:\\java\\workshop1\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp3\\wtpwebapps\\test\\upload";
		
		
		
		System.out.println("sss");
		MultipartRequest mr = new MultipartRequest(request, realPath,"utf-8");
		System.out.println(realPath);
		response.getWriter().println("upload OK");
	}
}
