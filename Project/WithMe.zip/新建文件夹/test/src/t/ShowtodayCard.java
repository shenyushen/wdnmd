package t;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

/**
 * Servlet implementation class ShowtodayCard
 */
@WebServlet("/ShowtodayCard")
public class ShowtodayCard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowtodayCard() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String param1 = request.getParameter("a");
		try {
			UserDao a = new UserDao();
			
		ResultSet rs = a.queryDate("select * from card where account = '"+param1+"'");
		int count = 0;
		PrintWriter writer = response.getWriter();
		 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
         //System.out.println(df.format(new Date()));// new Date()为获取当前系统时间
		
		writer.write("[");
			while(rs.next()) {
				
					
					if(rs.getString(2).equals(df.format(new Date()))) {
						if (count != 0)
							writer.write(",");
					writer.write("{");
					writer.write("\"account\":");
					writer.write("\""+rs.getString(1)+"\""+",");
					writer.write("\"Time\":");
					writer.write("\""+rs.getString(2)+"\""+",");
					writer.write("\"text\":");
					writer.write("\""+rs.getString(3)+"\""+"");
					writer.write("}");
					count=1;
					}
			}
		writer.write("]");
		//System.out.println("1");
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
