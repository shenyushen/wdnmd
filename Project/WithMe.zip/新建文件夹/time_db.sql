/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50506
Source Host           : localhost:3306
Source Database       : time_db

Target Server Type    : MYSQL
Target Server Version : 50506
File Encoding         : 65001

Date: 2019-12-19 09:37:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `card`
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `account` varchar(20) CHARACTER SET gbk DEFAULT NULL,
  `Time` varchar(30) DEFAULT NULL,
  `text` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of card
-- ----------------------------
INSERT INTO `card` VALUES ('asd', '2019-12-19', '每日跑步');
INSERT INTO `card` VALUES ('asd', '2019-12-18', '每日跑步');
INSERT INTO `card` VALUES ('asd', '2019-12-21', '早晨六级单词');
INSERT INTO `card` VALUES ('asd', '2019-12-22', '早晨六级单词');
INSERT INTO `card` VALUES ('asd', '2019-12-19', '早晨六级单词');
INSERT INTO `card` VALUES ('asd', '2019-12-20', '早晨六级单词');
INSERT INTO `card` VALUES ('asd', '2019-12-18', '早晨六级单词');
INSERT INTO `card` VALUES ('asd', '2019-12-20', '听一首英文歌');
INSERT INTO `card` VALUES ('asd', '2019-12-23', '听一首英文歌');
INSERT INTO `card` VALUES ('asd', '2019-12-21', '听一首英文歌');
INSERT INTO `card` VALUES ('asd', '2019-12-22', '听一首英文歌');
INSERT INTO `card` VALUES ('asd', '2019-12-18', '听一首英文歌');
INSERT INTO `card` VALUES ('sion', '2019-12-19', '');
INSERT INTO `card` VALUES ('sion', '2019-12-21', '');
INSERT INTO `card` VALUES ('sion', '2019-12-20', '');
INSERT INTO `card` VALUES ('sion', '2019-12-22', '');
INSERT INTO `card` VALUES ('a', '2019-12-19', '咱姑');
INSERT INTO `card` VALUES ('asd', '2019-12-21', 'aaa');
INSERT INTO `card` VALUES ('asd', '2019-12-22', 'aaa');
INSERT INTO `card` VALUES ('asd', '2019-12-20', 'aaa');
INSERT INTO `card` VALUES ('asd', '2019-12-23', 'aaa');

-- ----------------------------
-- Table structure for `comment`
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` varchar(20) DEFAULT NULL,
  `account` varchar(20) DEFAULT NULL,
  `text` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('2', 'asd', 'kkkk', '2019-12-17-09:52:15');
INSERT INTO `comment` VALUES ('3', 'a', '内沟翘', '2019-12-17-09:59:27');
INSERT INTO `comment` VALUES ('3', 'qweer', 'tule', '2019-12-18-15:54:12');
INSERT INTO `comment` VALUES ('1', 'asd', 'nnnn', '2019-12-18-16:16:13');
INSERT INTO `comment` VALUES ('1', 'asd', 'nvmvmnvm', '2019-12-18-16:16:24');
INSERT INTO `comment` VALUES ('4', 'zhang', '优秀', '2019-12-18-16:31:46');
INSERT INTO `comment` VALUES ('5', 'asd', '。。。', '2019-12-18-16:32:18');
INSERT INTO `comment` VALUES ('4', 'a', '一般般', '2019-12-18-16:35:36');
INSERT INTO `comment` VALUES ('2', 'asd', 'aaa', '2019-12-19-09:17:07');

-- ----------------------------
-- Table structure for `community`
-- ----------------------------
DROP TABLE IF EXISTS `community`;
CREATE TABLE `community` (
  `account` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `text` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of community
-- ----------------------------
INSERT INTO `community` VALUES ('asd', '2019-12-17-09:57:27', '冬天好冷', '2', '1576298819501.jpg`1576229712589.jpg`1576224841739.jpg`1575961190523.jpg');
INSERT INTO `community` VALUES ('a', '2019-12-17-09:58:20', '九张', '3', 'cat.jpeg`tom.jpeg`sh.jpg`sv.jpg`hg.jpg`1576504196022.jpeg`a.jpg`1576504267088.jpeg`1576504197954.jpeg');
INSERT INTO `community` VALUES ('a', '2019-12-18-16:27:11', '动图', '4', '-50e05d4410d95938.gif`683abce25d0442e7.gif`-1f0b946fd04cb9.gif`3E7A8D0F471D7209FCBFFE3A595A05FE.jpeg`CC67407721CAC1567979E5BA8B93826F.gif');
INSERT INTO `community` VALUES ('sion', '2019-12-18-16:30:16', '没想法', '5', '-73f56ceca725d7df.jpg');
INSERT INTO `community` VALUES ('a', '2019-12-19-09:18:26', 'sss', '6', '1576718292130.jpg`1576715573001.jpg');

-- ----------------------------
-- Table structure for `diary`
-- ----------------------------
DROP TABLE IF EXISTS `diary`;
CREATE TABLE `diary` (
  `account` varchar(20) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `text` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `zhuangtai` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of diary
-- ----------------------------
INSERT INTO `diary` VALUES ('qwee', '2020-01-17 09:19:00', '12', '0');
INSERT INTO `diary` VALUES ('qwee', '2020-04-17 09:20:00', '套路了', '0');
INSERT INTO `diary` VALUES ('qwee', '2018-01-17 09:25:00', '凌乱了', '0');
INSERT INTO `diary` VALUES ('zxc', '2017-01-17 01:01:00', 'sssss', '0');
INSERT INTO `diary` VALUES ('456', '2020-01-18 01:57:00', 'ssss', '0');
INSERT INTO `diary` VALUES ('eee', '2020-01-17 02:10:00', 'ssss', '0');
INSERT INTO `diary` VALUES ('asd', '2019-12-18 14:34:02', '今天跟男朋友出去逛街，好开心', '0');
INSERT INTO `diary` VALUES ('asd', '2019-12-19 14:35:18', '劳累的一天。。。', '0');
INSERT INTO `diary` VALUES ('asd', '2019-12-21 14:35:49', '男朋友牵了我的手好开心呀。', '0');
INSERT INTO `diary` VALUES ('asd', '2019-12-24 14:37:30', '快要放假了。', '0');
INSERT INTO `diary` VALUES ('a', '2020-01-20 06:58:00', '啊晚上而我', '0');
INSERT INTO `diary` VALUES ('a', '2020-01-18 06:59:00', '啊撒是1', '0');
INSERT INTO `diary` VALUES ('a', '2017-01-18 07:00:00', '1212', '0');
INSERT INTO `diary` VALUES ('qweer', '2020-01-18 07:47:00', 'das', '0');
INSERT INTO `diary` VALUES ('qweer', '2018-12-18 07:47:00', 'fdsfs', '0');
INSERT INTO `diary` VALUES ('qweer', '2019-01-18 07:48:00', 'dsad', '0');
INSERT INTO `diary` VALUES ('hhh', '2020-01-18 04:27:00', 'Ndndnd', '0');
INSERT INTO `diary` VALUES ('a', '2019-12-18 04:28:00', '测试', '0');
INSERT INTO `diary` VALUES ('asd', '2020-01-19 04:29:00', '嘿嘿', '0');
INSERT INTO `diary` VALUES ('hhh', '2020-01-18 04:31:00', 'Dnndnfn', '0');
INSERT INTO `diary` VALUES ('zhang', '2020-01-18 04:34:00', '自己来', '0');
INSERT INTO `diary` VALUES ('sion', '2024-05-24 04:40:00', 'vv滚滚滚', '0');
INSERT INTO `diary` VALUES ('sion', '2018-12-19 05:38:00', '法国还好吧', '0');
INSERT INTO `diary` VALUES ('zhang', '2020-01-18 04:36:00', '大家好', '0');
INSERT INTO `diary` VALUES ('sion', '2018-12-19 04:37:00', '好的好好说', '0');
INSERT INTO `diary` VALUES ('sion', '2019-12-19 04:37:00', '不上班不上班', '0');
INSERT INTO `diary` VALUES ('sion', '2019-12-20 04:38:00', '你睡吧你的', '0');
INSERT INTO `diary` VALUES ('asd', '2020-01-20 01:19:00', 'aaaa', '0');

-- ----------------------------
-- Table structure for `future`
-- ----------------------------
DROP TABLE IF EXISTS `future`;
CREATE TABLE `future` (
  `account` varchar(30) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `text` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of future
-- ----------------------------
INSERT INTO `future` VALUES ('qwee', 'null', '啊啊啊');
INSERT INTO `future` VALUES ('asd', '20191017', '未来的你，你好，看到这封信的时候');
INSERT INTO `future` VALUES ('asd', '20200117', '当你打开这封信的时候');
INSERT INTO `future` VALUES ('zxc', '20200117', 'sssssssss');
INSERT INTO `future` VALUES ('sion', '20220619', '12333');
INSERT INTO `future` VALUES ('asd', '20200219', 'dasdsa');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `account` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `sex` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `birthday` varchar(20) DEFAULT NULL,
  `hobby` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Personalsignature` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `user_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('123', '123', '111', 'null', 'null', 'null', 'null', 'null');
INSERT INTO `user` VALUES ('456', '456', '456', '男', 'null', 'null', 'null', 'IMG_20191204_070256.jpg');
INSERT INTO `user` VALUES ('a', '123', 'a', 'null', '2020-1-17', 'sb', '是哪个', 'c32511c12edd2684be9fa0742e5e18713ff1b64f.jpg');
INSERT INTO `user` VALUES ('asd', 'asd', '清风', '男', '2020-2-18', 'aaaa', 'null', 'IMG_20191204_070256.jpg');
INSERT INTO `user` VALUES ('bbb', 'bbb', 'bbb', 'null', 'null', 'null', 'null', 'null');
INSERT INTO `user` VALUES ('eee', 'eee', 'eee', '男', 'null', 'sss', 'sssa', 'IMG_20191204_070256.jpg');
INSERT INTO `user` VALUES ('hhh', 'hhh', 'hhh', 'null', 'null', 'null', 'null', 'null');
INSERT INTO `user` VALUES ('qwee', '123', '123', 'null', 'null', 'null', 'null', 'null');
INSERT INTO `user` VALUES ('qweer', '123', 'qwe', 'null', 'null', 'null', 'null', 'null');
INSERT INTO `user` VALUES ('sion', '123', 'SION', '女', '2025-1-18', '.', '?', '-7dabe197d9f2b83e.jpg');
INSERT INTO `user` VALUES ('zhang', '123', '张', '男', '1999-1-18', 'null', 'null', 'qq_pic_merged_1576590137067.jpg');
INSERT INTO `user` VALUES ('zxc', 'zxc', 'zxc', '女', 'null', 'null', 'null', 'IMG_20191204_070256.jpg');
