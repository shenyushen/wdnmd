package com.ldf.calendar.component;

/**
 * Created by ldf on 17/6/27.
 */

public enum State {
    CURRENT_MONTH, PAST_MONTH, NEXT_MONTH, SELECT
}
