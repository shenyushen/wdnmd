package com.example.a24168.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends BaseAdapter{
    /**
     * @Description:
     * @author by SIONON
     * @date 2019/12/4
     * @version V1.0
     */
    private List<Massage> texts = new ArrayList<>();
    private int itemLayoutId;
    private Context context;
    public CustomAdapter(Context context, List<Massage> texts, int itemLayoutId){

        this.context = context;
        this.texts = texts;
        this.itemLayoutId = itemLayoutId;
    }
    @Override


    public int getCount() {
        if (null != texts) {
            return texts.size();
        }else {
            return 0;
        }
    }

    @Override

    public Object getItem(int position) {
        if (null != texts) {
            return texts.get(position);
        }else {
            return null;
        }
    }

    @Override

    public long getItemId(int position) {
        return position;
    }

    @Override

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (null == convertView) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(itemLayoutId, null);
        }

        TextView name = convertView.findViewById(R.id.s1);
        name.setText(texts.get(position).getText());

        return convertView;
    }
}