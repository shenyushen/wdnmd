package com.example.a24168.myapplication.fragment.tabhost;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.example.a24168.myapplication.LetterAdapter;
import com.example.a24168.myapplication.R;
import com.example.a24168.myapplication.WriteLetter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;


public class ForFuture extends Fragment {
    public static LetterAdapter letterAdapter;
    public static    ArrayList<String[]> dat;
    private TextView tv_time;
    private Handler handler = new Handler();
   public  static Context context;
    public  static Context asdfghj;
    public  static ListView listView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       final View view = inflater.inflate(R.layout.forfuture,null);
        listView=view.findViewById(R.id.lvToDoList);
        asdfghj=getContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    int tag=0;
                    dat= new ArrayList<>();
                    URL url = new URL(getResources().getString(R.string.ip)+"/Query?user="+account);//放网站
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    InputStream in = httpURLConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    String line;
                    int i = 0;
                    while ((line = reader.readLine()) != null) {
                        String [] str=line.split(" ");
                        tag=1;
                        dat.add(str);

                    }

                    if(tag==1){
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                letterAdapter = new LetterAdapter(view.getContext(),dat, R.layout.forfuture_listview);
                                listView.setAdapter(letterAdapter);;

                            }
                        });
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
       FloatingActionButton bb = view.findViewById(R.id.button1);
       bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {//创建子线程
                    @Override
                    public void run() {
                        Intent intent = new Intent(view.getContext(),WriteLetter.class);
                        startActivity(intent);
                    }
                }).start();
                
            }
        });






        return view;
    }


}
