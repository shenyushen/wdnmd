package com.example.a24168.myapplication;

/*此页面是一个浏览图片的页面*/
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class lookimages extends AppCompatActivity {

    String imgs[] ;//图片数据
    int len  ;//数组第一个长度
    private ImageView mImg;//图片切换器
    private TextView textView;
    protected static final float FLIP_DISTANCE = 200;
    GestureDetector mDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lookimages);
        Intent in=getIntent();
        imgs=null;
        imgs=in.getStringArrayExtra("imgs");
        len=in.getIntExtra("position",0);
        mImg = findViewById(R.id.image);
        textView=findViewById(R.id.text);
        textView.setText("<"+(len+1)+"/"+imgs.length+">");
        if(len>= imgs.length){
            len= imgs.length-1;
        }
        Log.e("zhihou",len+" "+imgs[0]);
        Glide.with(this)
                .load(getResources().getString(R.string.ip)+"/upload/"+imgs[len])
                .into(mImg);
        mDetector = new GestureDetector(this, new GestureDetector.OnGestureListener() {

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                // TODO Auto-generated method stub
                return false;
            }

            @Override
            public void onShowPress(MotionEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                // TODO Auto-generated method stub
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                // TODO Auto-generated method stub

            }

            /**
             *
             * e1 The first down motion event that started the fling. e2 The
             * move motion event that triggered the current onFling.
             */
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1.getX() - e2.getX() > FLIP_DISTANCE) {
                    Log.i("MYTAG", "向左滑...");
                    if(len<imgs.length-1){
                        len++;
                    }
                    else{
                        len=0;
                    }
                    Glide.with(getBaseContext())
                            .load(getResources().getString(R.string.ip)+"/upload/"+imgs[len])
                            .into(mImg);
                    textView.setText("<"+(len+1)+"/"+imgs.length+">");
                    return true;
                }
                if (e2.getX() - e1.getX() > FLIP_DISTANCE) {
                    Log.i("MYTAG", "向右滑...");
                    if(len>0){
                        len--;
                    }
                    else{
                        len=imgs.length-1;
                    }
                    Glide.with(getBaseContext())
                            .load(getResources().getString(R.string.ip)+"/upload/"+imgs[len])
                            .into(mImg);
                    textView.setText("<"+(len+1)+"/"+imgs.length+">");
                    return true;
                }
                if (e1.getY() - e2.getY() > FLIP_DISTANCE) {
                    Log.i("MYTAG", "向上滑...");
                    return true;
                }
                if (e2.getY() - e1.getY() > FLIP_DISTANCE) {
                    Log.i("MYTAG", "向下滑...");
                    return true;
                }

                Log.d("TAG", e2.getX() + " " + e2.getY());

                return false;
            }

            @Override
            public boolean onDown(MotionEvent e) {
                // TODO Auto-generated method stub
                return false;
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mDetector.onTouchEvent(event);
    }
}