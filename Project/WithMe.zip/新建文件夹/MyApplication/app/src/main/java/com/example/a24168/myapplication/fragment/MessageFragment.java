package com.example.a24168.myapplication.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.example.a24168.myapplication.R;
import com.example.a24168.myapplication.messgae_Adapter;
import com.example.a24168.myapplication.ui.MainActivity1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class MessageFragment extends Fragment {
    public static ListView listView;
    private View view;
    private TextView textView;
    public static Context contextfram;
    private Handler handler = new Handler();
    public static List<messgae_Adapter.message_user> message_userList;
    public static String account;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view == null){
            view = inflater.inflate(R.layout.message_layout, container, false);
        }

        listView=view.findViewById(R.id.message_listview);
        contextfram=getContext();
        textView=view.findViewById(R.id.add_messagetime);
        /*社区*/
        /*添加社区*/
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(getContext(), MainActivity1.class);
                startActivity(intent);
            }
        });
        messageview();
        return view;
    }





    /*显示朋友圈函数*/
    public void messageview(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    message_userList=new ArrayList<messgae_Adapter.message_user>();
                    //1,找水源--创建URL
                    URL url = new URL(getResources().getString(R.string.ip)+"/message?que=lookmessage");//放网站
                    //2,开水闸--openConnection
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    //3，建管道--InputStream
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    InputStream in = httpURLConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String [] str=line.split(" ");
                        messgae_Adapter.message_user m=new messgae_Adapter.message_user(str[0],str[1],str[2],str[3],str[4],str[5].split("`"));
                        message_userList.add(m);
                    }
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            messgae_Adapter m=new messgae_Adapter(getContext(),message_userList,R.layout.messagelayout);
                            listView.setAdapter(m);
                        }
                    });

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
