package com.example.a24168.myapplication;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.example.a24168.myapplication.R;


public class commomDialog2 extends AlertDialog implements View.OnClickListener{
    private TextView contentTxt;
    private TextView titleTxt;
    private TextView submitTxt;
    private TextView cancelTxt;


    private Context mContext;
    private String content;
    private ParcelFileDescriptor.OnCloseListener listener;
    private String positiveName;
    private String negativeName;
    private String title;


    public commomDialog2(@NonNull Context context) {
        super(context);
        this.mContext = context;

    }

    public commomDialog2(@NonNull Context context, int themeResId,String content) {
        super(context, themeResId);
        this.mContext = context;
        this.content = content;
    }

    protected commomDialog2(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        this.mContext = context;
    }
    public commomDialog2 setTitle(String title){
        this.title = title;
        return this;
    }


    public commomDialog2 setPositiveButton(String name){
        this.positiveName = name;
        return this;
    }


    public commomDialog2 setNegativeButton(String name){
        this.negativeName = name;
        return this;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.commomdialog);
        setCanceledOnTouchOutside(false);
        initView();
    }
    private void initView(){
        contentTxt = (TextView)findViewById(R.id.content);
        titleTxt = (TextView)findViewById(R.id.title);
        submitTxt = (TextView)findViewById(R.id.submit);
        submitTxt.setOnClickListener(this);
        cancelTxt = (TextView)findViewById(R.id.cancel);
        cancelTxt.setOnClickListener(this);


        contentTxt.setText(content);
        if(!TextUtils.isEmpty(positiveName)){
            submitTxt.setText(positiveName);
        }


        if(!TextUtils.isEmpty(negativeName)){
            cancelTxt.setText(negativeName);
        }


        if(!TextUtils.isEmpty(title)){
            titleTxt.setText(title);
        }


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cancel:
                if(listener == null){
                    this.dismiss();
                }

                break;
            case R.id.submit:
                //完成打卡操作


                this.dismiss();
                break;
        }

    }


}
