package com.example.a24168.myapplication;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Description:
 * Data：7/5/2018-3:43 PM
 *
 * @author yanzhiwen
 */
@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
