package com.example.a24168.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;
import static com.example.a24168.myapplication.fragment.tabhost.ForFuture.asdfghj;
import static com.example.a24168.myapplication.fragment.tabhost.ForFuture.dat;
import static com.example.a24168.myapplication.fragment.tabhost.ForFuture.letterAdapter;
import static com.example.a24168.myapplication.fragment.tabhost.ForFuture.listView;


public class LetterAdapter extends BaseAdapter {
    private Handler handler = new Handler();
    private List<String[]> letterList = new ArrayList<>();
    private int itemLayoutId;
    static Context context;

    public LetterAdapter(Context context, List<String[]>letterList, int itemLayoutId){
        this.context=context;
        this.itemLayoutId=itemLayoutId;
        this.letterList=letterList;
    }
    @Override
    public int getCount() {
        if(null !=letterList) {
            return letterList.size();
        }else {
            return 0;
        }
    }

    @Override
    public Object getItem(int position) {
        if(null !=letterList){
            return letterList.get(position);
        }else{
            return null;
        }
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (null == convertView) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(itemLayoutId, null);
        }
        TextView txt_datetime=convertView.findViewById(R.id.txt_datetime);
        TextView txt_letter=convertView.findViewById(R.id.txt_letter);
        txt_datetime.setText("寄往"+letterList.get(position)[0]+"   ");
        txt_letter.setText(letterList.get(position)[1].substring(0,3)+"......");
        final long a=Long.parseLong(letterList.get(position)[0]);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = new Date(System.currentTimeMillis());
        final long b=Long.parseLong(simpleDateFormat.format(date));
        //Log.e("ggg",simpleDateFormat.format(date));

        txt_letter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(b>=a){
                    AlertDialog.Builder dialog=new AlertDialog.Builder(context);

                    TextView title=new TextView(context);
                    title.setHeight(190);
                    title.setWidth(400);
                    title.setText("致未来的自己");
                    title.setPadding(10, 10, 10, 10);
                    title.setGravity(Gravity.CENTER);
                    title.setTextColor(Color.parseColor("#292421"));
                    title.setLetterSpacing(0.2f);
                    title.setTextSize(22);
                    TextView msg = new TextView(context);
                    msg.setText(letterList.get(position)[1]);
                    msg.setPadding(40, 10, 30, 30);
                    //msg.setHeight(800);
                    msg.setWidth(400);
                    msg.setTextSize(16);
                    msg.setLineSpacing(0,1f);
                    msg.setLetterSpacing(0.2f);
                    dialog.setCustomTitle(title);
                    dialog.setView(msg);
                    //dialog.create();

                    dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    final AlertDialog dialog1=dialog.create();
                    dialog1.show();

                    final Button positiveButton = dialog1.getButton(AlertDialog.BUTTON_POSITIVE);
                    final Button negativeButton = dialog1.getButton(AlertDialog.BUTTON_NEGATIVE);
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) positiveButton.getLayoutParams();
                    layoutParams.weight = 10;
                    positiveButton.setLayoutParams(layoutParams);
                    negativeButton.setLayoutParams(layoutParams);
                }else{
                    Toast t = Toast.makeText(context,"还未到开启时间", Toast.LENGTH_LONG);
                    t.show();
                }

            }
        });

        txt_datetime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(b>=a){
                    AlertDialog.Builder dialog=new AlertDialog.Builder(context);

                    TextView title=new TextView(context);
                    title.setHeight(190);
                    title.setWidth(400);
                    title.setText("致未来的自己");
                    title.setPadding(10, 10, 10, 10);
                    title.setGravity(Gravity.CENTER);
                    title.setTextColor(Color.parseColor("#292421"));
                    title.setLetterSpacing(0.2f);
                    title.setTextSize(22);
                    TextView msg = new TextView(context);
                    msg.setText(letterList.get(position)[1]);
                    msg.setPadding(40, 10, 30, 30);
                    //msg.setHeight(800);
                    msg.setWidth(400);
                    msg.setTextSize(16);
                    msg.setLineSpacing(0,1f);
                    msg.setLetterSpacing(0.2f);
                    dialog.setCustomTitle(title);
                    dialog.setView(msg);
                    //dialog.create();

                    dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    final AlertDialog dialog1=dialog.create();
                    dialog1.show();

                    final Button positiveButton = dialog1.getButton(AlertDialog.BUTTON_POSITIVE);
                    final Button negativeButton = dialog1.getButton(AlertDialog.BUTTON_NEGATIVE);
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) positiveButton.getLayoutParams();
                    layoutParams.weight = 10;
                    positiveButton.setLayoutParams(layoutParams);
                    negativeButton.setLayoutParams(layoutParams);
                }else{
                    Toast t = Toast.makeText(context,"还未到开启时间", Toast.LENGTH_LONG);
                    t.show();
                }

            }

        });


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                //定义AlertDialog.Builder对象，当长按列表项的时候弹出确认删除对话框
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setMessage("确定删除信件?");
                builder.setTitle("提示");
                Log.e("seses","长按");
                //添加AlertDialog.Builder对象的setPositiveButton()方法
                builder.setPositiveButton("确定",new DialogInterface.OnClickListener()  {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    final String datetime=letterList.get(position)[0];
                                    final String letter=letterList.get(position)[1];
                                    int tag=0;
                                    URL url = new URL(context.getResources().getString(R.string.ip)+"/Delete?user="+account+"&datetime="+datetime);//放网站
                                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                                    httpURLConnection.setRequestMethod("GET");
                                    httpURLConnection.setConnectTimeout(8000);
                                    httpURLConnection.setReadTimeout(8000);
                                    InputStream in = httpURLConnection.getInputStream();
                                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                                    handler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            dat.remove(position);
                                            letterAdapter = new LetterAdapter(asdfghj,dat, R.layout.forfuture_listview);
                                            listView.setAdapter(letterAdapter);
                                        }
                                    });

                                } catch (MalformedURLException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }).start();
                    }
                });

                //添加AlertDialog.Builder对象的setNegativeButton()方法
                builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.create().show();

                return true;
            }
        });


        return convertView;
    }
}
