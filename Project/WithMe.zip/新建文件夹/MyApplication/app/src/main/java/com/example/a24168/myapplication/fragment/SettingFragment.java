package com.example.a24168.myapplication.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.a24168.myapplication.Detail;
import com.example.a24168.myapplication.R;
import com.example.a24168.myapplication.Sign;
import com.example.a24168.myapplication.list;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;

public class SettingFragment extends Fragment  {
    public static String nick;
    public static list str=new list();
    public static Context az;
    private Button btn11;
    private Button btn_sign;
    private  Handler handler = new Handler();
    View view;
    TextView tv0;
   public static TextView tv1;
    public static TextView tv2;
    public static  TextView tv3;
    public static  TextView tv4;
    public static  TextView tv5;
   public static ImageView ima;

    private void getViews() {
        btn11 = view.findViewById(R.id.btn11);
        btn_sign = view.findViewById(R.id.btn_sign);
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view == null){
            view = inflater.inflate(R.layout.settings_layout, container, false);
        }

        az = getContext();
        getViews();
        btn_sign.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                Intent sign = new Intent(getContext(), Sign.class);
                startActivity(sign);
            }
        });
        //详情信息
        btn11.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                Intent detail = new Intent(getContext(), Detail.class);
                startActivity(detail);
            }
        });

        //接收登录账号传值

        tv5 = view.findViewById(R.id.edt_zhang);
        tv5.setText(account);

        tv0=view.findViewById(R.id.edt_ming);
        tv1=view.findViewById(R.id.edt_xing);
        tv2=view.findViewById(R.id.edt_sheng);
        tv3=view.findViewById(R.id.edt_ai);
        tv4=view.findViewById(R.id.edt_qian);
        ima=view.findViewById(R.id.head1);
        xian(account);
       /* Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                //Log.e("TAG","没隔2秒执行一次操作");

            }
        },1000,1000);*/


        return view;
    }

    public void xian(final String account){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/viewuser");
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String info = reader.readLine();
                    try {
                        JSONArray jsonArray = new JSONArray(info);
                        for(int i = 0; i < jsonArray.length();i++){
                            if(jsonArray.getJSONObject(i).getString("account").equals(account)){
                                str.setNames(jsonArray.getJSONObject(i).getString("name"));
                                str.setSex(jsonArray.getJSONObject(i).getString("sex"));
                                str.setBirthday(jsonArray.getJSONObject(i).getString("birthday"));
                                str.setHobby(jsonArray.getJSONObject(i).getString("hobby"));
                                str.setPersonalsignature(jsonArray.getJSONObject(i).getString("Personalsignature"));
                                str.setImage(jsonArray.getJSONObject(i).getString("Image"));
                                //Log.e("zsssssssss",str.getImage());
                                tv0.setText(str.getNames());
                                nick=str.getNames();
                                if(str.getSex().equals("null")){
                                    tv1.setText("未填写");
                                }else{
                                    tv1.setText(str.getSex());
                                }
                                if(str.getBirthday().equals("null")){
                                    tv2.setText("未填写");
                                }else{
                                    tv2.setText(str.getBirthday());
                                }
                                if(str.getHobby().equals("null")){
                                    tv3.setText("未填写");
                                }else{
                                    tv3.setText(str.getHobby());
                                }
                                if(str.getPersonalsignature().equals("null")){
                                    tv4.setText("这个人很懒，什么都没有留下");
                                }else{
                                    tv4.setText(str.getPersonalsignature());
                                }
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if(!str.getImage().equals("null")) {
                                            Glide.with(getContext())
                                                    .load(getResources().getString(R.string.ip) + "/upload/" + str.getImage())
                                                    .into(ima);
                                        }else{

                                        }
                                        Log.e("aaa","b");
                                    }

                                });
                            break;
                            }
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

}
