package com.example.a24168.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.Random;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


import static com.example.a24168.myapplication.fragment.MessageFragment.account;
import static com.example.a24168.myapplication.fragment.SettingFragment.az;
import static com.example.a24168.myapplication.fragment.SettingFragment.nick;
import static com.example.a24168.myapplication.fragment.SettingFragment.ima;
import static com.example.a24168.myapplication.fragment.SettingFragment.tv1;
import static com.example.a24168.myapplication.fragment.SettingFragment.tv2;
import static com.example.a24168.myapplication.fragment.SettingFragment.tv3;
import static com.example.a24168.myapplication.fragment.SettingFragment.tv4;

public class Detail extends AppCompatActivity implements View.OnClickListener, UploadUtil.OnUploadProcessListener {

    private String sex;
    private String name;
    Uri uri;
    private String hobby=null;
    private String a=null;
    private String person=null;
    Handler handler = new Handler();
    private DatePicker dp;
    private AlertDialog alertDialog2; //单选框
    private View inflate;
    private TextView choosePhoto;
    private TextView takePhoto;
    private Dialog dialog;

    private RelativeLayout btn;
    private RelativeLayout btn1;
    private RelativeLayout btn2;
    private RelativeLayout btn3;
    private Button b_t;
    View view;


    private RelativeLayout R1;
    private ImageView head;
    private Button btn_change;
    private ProgressDialog pd;
    private File filepath;//返回的文件地址
    /**
     * 判断的标识
     */
    private static final int PHOTO_REQUEST = 1;
    private static final int PHOTO_CLIP = 3;
    private static final int UPLOAD_INIT_PROCESS = 4;//上传初始化
    protected static final int UPLOAD_FILE_DONE = 2;//上传中
    private static final int UPLOAD_IN_PROCESS = 5;//上传文件响应

    private TextView tv8;
    private TextView tv9;
    private int temp;
    private String tep;
    private TextView t_sex;
    private TextView t_birthday;
    private TextView t_hobby;
    private TextView t_person;



    private void getViews() {
        btn = findViewById(R.id.r);
        btn1 = findViewById(R.id.r1);
        btn2 = findViewById(R.id.r2);
        btn3 = findViewById(R.id.r3);
        b_t=findViewById(R.id.b_t);
        t_sex=findViewById(R.id.t_sex);
        t_birthday=findViewById(R.id.t_birthday);
        t_hobby=findViewById(R.id.t_hobby);
        t_person=findViewById(R.id.t_person);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);

        //昵称传值
        // Log.e("zssssss",nick);
        tv8=findViewById(R.id.edt1);
        tv8.setText(nick);

        getViews();
        //接收登录账号传值

        tv9 = findViewById(R.id.edt2);
        tv9.setText(account);
        //显示选择的信息





        b_t.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        //选择性别
        btn.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                showSingleAlertDialog();
            }
        });
        //出生日期
        btn1.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                show();
            }
        });
        //爱好
        btn2.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                hobby();
            }
        });
        //个性签名
        btn3.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                person();
            }
        });

        head = (ImageView) findViewById(R.id.head);
        //头像上传
        initView();
        btn_change.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                getPhoto();
            }
        });

    }

    //选择性别
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.mian,menu);
        return true;
    }


    public void showSingleAlertDialog() {
        final String[] items = {"男", "女"};
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder( this);
        alertBuilder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText( Detail.this, items[i], Toast.LENGTH_SHORT).show();
                sex = items[i];
                t_sex.setText(sex);
                tv1.setText(sex);
                Log.e("xxx",tv1.getText().toString());
                upsex();
                alertDialog2.dismiss();
            }
        });
        alertDialog2 = alertBuilder.create();
        alertDialog2.show();
    }


    //爱好
    public void hobby() {
        final EditText et1 = new EditText( this);
        new AlertDialog.Builder( this).setTitle("请输入您的爱好")
                .setView(et1)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //按下确定键后的事件
                        Toast.makeText( Detail.this, et1.getText().toString(), Toast.LENGTH_LONG).show();
                        hobby = et1.getText().toString();
                        t_hobby.setText(hobby);
                        tv3.setText(hobby);
                        uphobby();
                        //Log.e("zxw",et1.getText().toString());
                    }
                }).setNegativeButton("取消", null).show();
    }


    //个性签名
    public void person() {
        final EditText et = new EditText( this);
        new AlertDialog.Builder( this).setTitle("请输入个性签名")
                .setView(et)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //按下确定键后的事件
                        Toast.makeText( Detail.this, et.getText().toString(), Toast.LENGTH_LONG).show();
                        person = et.getText().toString();
                        t_person.setText(person);
                        tv4.setText(person);
                       upperson();
                        //Log.e("zxw",et.getText().toString());
                    }
                }).setNegativeButton("取消", null).show();
    }

    //选择出生年月
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.takePhoto:
                String year=dp.getYear()+"-";
                String month=dp.getMonth()+1+"-";
                String day=dp.getDayOfMonth()+"";
                a=year+month+day;
                t_birthday.setText(a);
                break;
            case R.id.choosePhoto:
                break;
        }
        tv2.setText(a);
        upbirthday();
        dialog.dismiss();
    }

    public String show() {
        String time = null;
        dialog = new Dialog( this, R.style.ActionSheetDialogStyle);
        //填充对话框的布局
        inflate = LayoutInflater.from( this).inflate(R.layout.duihuakuang1, null);
        //初始化控件
        dp = (DatePicker) inflate.findViewById(R.id.dp);
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);

        int month = cal.get(Calendar.MONTH) + 1;//特殊的是Calendar中月份从0开始计数，所以加1得到常规月份

        final int day = cal.get(Calendar.DAY_OF_MONTH);
        //setTitle(year+"-"+month+"-"+day);
        dp.init(year, month, day, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //setTitle(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);

            }
        });
        choosePhoto = (TextView) inflate.findViewById(R.id.choosePhoto);
        takePhoto = (TextView) inflate.findViewById(R.id.takePhoto);
        choosePhoto.setOnClickListener(this);
        takePhoto.setOnClickListener(this);
        //将布局设置给Dialog
        dialog.setContentView(inflate);
        //获取当前Activity所在的窗体
        Window dialogWindow = dialog.getWindow();
        //设置Dialog从窗体底部弹出
        dialogWindow.setGravity(Gravity.BOTTOM);
        //获得窗体的属性
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.y = 20;//设置Dialog距离底部的距离
        //    将属性设置给窗体
        dialogWindow.setAttributes(lp);
        dialog.show();//显示对话框
        return time;
    }

    //连接数据库插入数据
    private void upsex(){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/upsex?sex="+sex +"&account="+account);
                    Log.e("sss",url.toString());
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void upbirthday(){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/upbirthday?birthday="+a +"&account="+account);
                    Log.e("sss",url.toString());
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void uphobby(){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/uphobby?hobby="+hobby +"&account="+account);
                    Log.e("sss",url.toString());
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void upperson(){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/upperson?Personalsignature="+person +"&account="+account);
                    Log.e("sss",url.toString());
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void initView() {
        R1 = (RelativeLayout) findViewById(R.id.R1);
        btn_change = (Button) findViewById(R.id.btn_change);
        btn_change.setOnClickListener(this);
    }

    /**
     * 从相册选择图片来源
     */
    private void getPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "image/*");
        startActivityForResult(intent, PHOTO_CLIP);
    }

    /****
     * 调用系统自带切图工具对图片进行裁剪
     * 微信也是
     *
     * @param uri
     */
    private void photoClip(Uri uri) {
        // 调用系统中自带的图片剪裁
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // 下面这个crop=true是设置在开启的Intent中设置显示的VIEW可裁剪
        intent.putExtra("crop", "false");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
       // intent.putExtra("return-data", true);
        startActivityForResult(intent, PHOTO_CLIP);
    }

    /**
     * 上传服务器响应回调
     */
    @Override
    public void onUploadDone(int responseCode, String message) {
        //上传完成响应
        pd.dismiss();
        Message msg = Message.obtain();
        msg.what = UPLOAD_FILE_DONE;
        msg.arg1 = responseCode;
        msg.obj = message;
    }

    @Override
    public void onUploadProcess(int uploadSize) {
        //上传中
        Message msg = Message.obtain();
        msg.what = UPLOAD_IN_PROCESS;
        msg.arg1 = uploadSize;
    }

    @Override
    public void initUpload(int fileSize) {
        //准备上传
        Message msg = Message.obtain();
        msg.what = UPLOAD_INIT_PROCESS;
        msg.arg1 = fileSize;
    }
    public String getPAth(Uri uri) {
        String path = null;
        if (!TextUtils.isEmpty(uri.getAuthority())) {
            Cursor cursor = getContentResolver().query(uri,
                    new String[]{MediaStore.Images.Media.DATA}, null, null, null);
            if (null == cursor) {
                Toast.makeText(this, "图片没找到", Toast.LENGTH_SHORT).show();
                return null;
            }
            cursor.moveToFirst();
            path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            cursor.close();
        } else {
            path = uri.getPath();
        }
        return path;
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case PHOTO_REQUEST://从相册取
                if (data != null) {
                    Uri uri = data.getData();
                    //对相册取出照片进行裁剪
                    photoClip(uri);

                }
                break;
            case PHOTO_CLIP:
                //完成
                if (Build.VERSION.SDK_INT >= 23) {
                    int REQUEST_CODE_CONTACT = 101;
                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    //验证是否许可权限
                    for (String str : permissions) {
                        if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                            //申请权限
                            this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                            return;
                        }
                    }
                }

                if (data!=null) {
                    uri = data.getData();
                }
                String path = getPAth(uri);
                Log.e("12334",path);
                String [] a = path.split("/");

                RequestOptions options =new RequestOptions()
                        .override(150,100);
                Glide.with(this)
                        .load(path)
                        .into(head);
                Log.e("aaa",path);

                    Bundle extras = data.getExtras();

                       // Bitmap photo = extras.getParcelable("data");
                        //获得图片路径
                        //Environment.getExternalStorageDirectory().toString()
                        tep=account+".jpg";
                        File file = new File(path);
                        // filepath = UploadUtil.saveFile(photo,path, tep);
                        Log.e("1111",Environment.getExternalStorageDirectory().toString());

                        //上传照片
                        new Thread(){
                            public void run(){
                                OkHttpClient client = new OkHttpClient();
                                String encrypt="multipart/form-data";
                                RequestBody fileBody = RequestBody.create(MediaType.parse("image/jpg"),file);
                                RequestBody requestBody = new MultipartBody.Builder()
                                        .setType(MultipartBody.FORM)
                                        .addFormDataPart("file",a[a.length-1], fileBody)
                                        .addFormDataPart("imagetype",encrypt)
                                        .build();
                                Request.Builder builder = new Request.Builder();
                                Request request = builder.post(requestBody).url(getResources().getString(R.string.ip)+"/uptou?Image="+a[a.length-1]+"&account="+account).build();

                                Log.e("12345",path);
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Glide.with(az)
                                                .load(getResources().getString(R.string.ip)+"/upload/"+a[a.length-1])
                                                .into(ima);
                                        Log.e("aaa","a");
                                    }

                                });

                                try {
                                    Response response = client.newCall(request).execute();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }.start();
                break;
        }
    }

}
