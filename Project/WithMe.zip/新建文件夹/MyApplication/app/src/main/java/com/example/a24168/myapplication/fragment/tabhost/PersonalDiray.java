package com.example.a24168.myapplication.fragment.tabhost;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a24168.myapplication.NewListView;
import com.example.a24168.myapplication.TimelineAdapter;
import com.example.a24168.myapplication.CustomAdapter;
import com.example.a24168.myapplication.CustomDayView;
import com.example.a24168.myapplication.ExampleAdapter;
import com.example.a24168.myapplication.Massage;
import com.example.a24168.myapplication.R;
import com.example.a24168.myapplication.ThemeDayView;
import com.ldf.calendar.Utils;
import com.ldf.calendar.component.CalendarAttr;
import com.ldf.calendar.component.CalendarViewAdapter;
import com.ldf.calendar.interf.OnSelectDateListener;
import com.ldf.calendar.model.CalendarDate;
import com.ldf.calendar.view.Calendar;
import com.ldf.calendar.view.MonthPager;
import com.example.a24168.myapplication.newclass;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;

public class PersonalDiray extends Fragment {
    View view;
    int i = 0;
    TextView tvYear;
    TextView tvMonth;
    TextView backToday;
    CoordinatorLayout content;
    MonthPager monthPager;
    RecyclerView rvToDoList;
    TextView scrollSwitch;
    TextView themeSwitch;
    TextView nextMonthBtn;
    TextView lastMonthBtn;
    TextView ivTextView;
    public static ArrayList<Massage> test;
    private Handler handler;
    private ArrayList<Calendar> currentCalendars = new ArrayList<>();
    private CalendarViewAdapter calendarAdapter;
    private OnSelectDateListener onSelectDateListener;
    private int mCurrentPage = MonthPager.CURRENT_DAY_INDEX;
    private Context context;
    private CalendarDate currentDate;
    private boolean initiated = false;
    private int min;
    public Button button1;
    private FloatingActionButton button;
    private NewListView listView;
    List<String> data ;
    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();


    private TimelineAdapter timelineAdapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        /*
         私人日志
         */
        // 轴视图
        if (view == null) {
            view = inflater.inflate(R.layout.personaldiray,container,false);
        }
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }
        button = view.findViewById(R.id.ActionButton);
        listView = (NewListView) view.findViewById(R.id.listview);
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 1) {
                    listView.setDividerHeight(0);
                    scrollMyListViewToBottom();
                    listView.setVisibleItemCount(3);
                    Log.e("1221", String.valueOf(list.size()));
                    timelineAdapter = new TimelineAdapter(getContext(), getData());
                    listView.setAdapter(timelineAdapter);
                }

            }
        };

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final String text = (String) ((TextView)view.findViewById(R.id.title)).getText();
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setMessage("确定删除吗？");
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        new Thread() {

                            public void run() {
                                try {
                                    URL url = new URL(getResources().getString(R.string.ip)+"/DeleteDiaryzxw?a=" + account + "&b=" + text);
                                    URLConnection conn = url.openConnection();
                                    InputStream in = conn.getInputStream();

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }.start();
                        if(list.get(position).get("show_time").toString()!="") {
                            list.remove(position);
                            timelineAdapter.notifyDataSetChanged();
                        }


                        Toast.makeText(getContext(), "positive: ", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(getContext(), "negative: ", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
                return false;
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), newclass.class);
                startActivity(intent);
            }
        });

        sendToServer(getResources().getString(R.string.ip)+"/Diaryzxw?account="+account);





        //日历模式
        show();

        Button button = view.findViewById(R.id.btn);
        LinearLayout linearLayout = view.findViewById(R.id.rili);
        FrameLayout linearLayout1 = view.findViewById(R.id.zhou);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(i ==0) {
                    //切换到日历视图
                    button.setBackgroundResource(R.drawable.close);
                    linearLayout.setVisibility(View.VISIBLE);
                    linearLayout1.setVisibility(View.GONE);
                    i = 1;
                }
                else{
                    //切换到轴视图
                    button.setBackgroundResource(R.drawable.open);
                    linearLayout.setVisibility(View.GONE);
                    linearLayout1.setVisibility(View.VISIBLE);
                    i = 0;
                }
            }
        });
        return view;
    }
    /*
    轴视图
     */
    private void scrollMyListViewToBottom() {
        listView.post(new Runnable() {
            @Override
            public void run() {
                // Select the last row so it will scroll into view...
                listView.setSelection(min-1);
            }
        });
    }

    private void sendToServer(String u) {
        final String a = u;
        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("title", "");
        map.put("show_time", "");
        list.add(map);
        Log.e("zxw",a);
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(a);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String info = reader.readLine();
                    try {
                        Log.e("zxw","输出");
                        JSONArray jsonArray = new JSONArray(info);
                        for(int i = 0; i < jsonArray.length();i++){
                            Map<String, Object> map = new HashMap<String, Object>();
                            map.put("title",jsonArray.getJSONObject(i).getString("text"));
                            map.put("show_time", jsonArray.getJSONObject(i).getString("time"));

                            list.add(map);


                        }
                        if(list.size() >= 1)
                            min = jsonArray.getJSONObject(0).getInt("abc");
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    Message msg = Message.obtain();
                    msg.obj = list;
                    msg.what = 1;
                    handler.sendMessage(msg);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private List<Map<String, Object>> getData() {


        Map<String, Object> map = new HashMap<String, Object>();
        map.put("title", "");
        map.put("show_time", "");
        list.add(map);
        return list;
    }




    /*

        日历模式展示

     */
    private void show() {

        context = view.getContext();
        content = (CoordinatorLayout) view.findViewById(R.id.content);
        monthPager = (MonthPager) view.findViewById(R.id.calendar_view);
        //此处强行setViewHeight，毕竟你知道你的日历牌的高度
        monthPager.setViewHeight(Utils.dpi2px(context, 270));
        tvYear = (TextView) view.findViewById(R.id.show_year_view);
        tvMonth = (TextView) view.findViewById(R.id.show_month_view);
        backToday = (TextView) view.findViewById(R.id.back_today_button);
        nextMonthBtn = (TextView) view.findViewById(R.id.next_month);
        lastMonthBtn = (TextView)view. findViewById(R.id.last_month);
        rvToDoList = (RecyclerView) view.findViewById(R.id.list);
        scrollSwitch = (TextView) view.findViewById(R.id.scroll_switch);
        rvToDoList.setHasFixedSize(true);
        //这里用线性显示 类似于listview
        rvToDoList.setLayoutManager(new LinearLayoutManager(context));
        rvToDoList.setAdapter(new ExampleAdapter(context));

        initCurrentDate();
        initCalendarView();
     //   refreshMonthPager();

        initToolbarClickListener();

        Log.e("ldf","OnCreated");
        getMassage();
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                ListView listView = view.findViewById(R.id.lv_persons);
                if(msg.what == 90 ){
                    test = (ArrayList<Massage>) msg.obj;
                }
            }
        };
    }
    /**
     * onWindowFocusChanged回调时，将当前月的种子日期修改为今天
     *
     * @return void
     */


    /*
     * 如果你想以周模式启动你的日历，请在onResume是调用
     * Utils.scrollTo(content, rvToDoList, monthPager.getCellHeight(), 200);
     * calendarAdapter.switchToWeek(monthPager.getRowIndex());
     * */
/*
    @Override
    public void onResume() {

        Utils.scrollTo(content, rvToDoList, monthPager.getCellHeight(), 200);
        calendarAdapter.switchToWeek(monthPager.getRowIndex());
        super.onResume();
    }
*/
    /**
     * 初始化对应功能的listener
     *
     * @return void
     */
    private void initToolbarClickListener() {
        backToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickBackToDayBtn();
            }
        });

        scrollSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (calendarAdapter.getCalendarType() == CalendarAttr.CalendarType.WEEK) {
                   Utils.scrollTo(content, rvToDoList, monthPager.getViewHeight(), 200);
                    calendarAdapter.switchToMonth();

                } else {
                  Utils.scrollTo(content, rvToDoList, monthPager.getCellHeight(), 200);
                    calendarAdapter.switchToWeek(monthPager.getRowIndex());
                    Log.e("123","2222");
                }
            }
        });
       scrollSwitch.performClick();
        scrollSwitch.performClick();
        nextMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                monthPager.setCurrentItem(monthPager.getCurrentPosition() + 1);
            }
        });
        lastMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                monthPager.setCurrentItem(monthPager.getCurrentPosition() - 1);
            }
        });
    }

    /**
     * 初始化currentDate
     *
     * @return void
     */
    private void initCurrentDate() {
        currentDate = new CalendarDate();
        tvYear.setText(currentDate.getYear() + "年");
        tvMonth.setText(currentDate.getMonth() + "");
    }

    /**
     * 初始化CustomDayView，并作为CalendarViewAdapter的参数传入
     */
    private void initCalendarView() {
        initListener();
        CustomDayView customDayView = new CustomDayView(context, R.layout.custom_day);
        calendarAdapter = new CalendarViewAdapter(
                context,
                onSelectDateListener,
                CalendarAttr.WeekArrayType.Monday,
                customDayView);
        calendarAdapter.setOnCalendarTypeChangedListener(new CalendarViewAdapter.OnCalendarTypeChanged() {
            @Override
            public void onCalendarTypeChanged(CalendarAttr.CalendarType type) {
                rvToDoList.scrollToPosition(0);
            }
        });
        initMarkData();
        initMonthPager();
    }

    /**
     * 初始化标记数据，HashMap的形式，可自定义
     * 如果存在异步的话，在使用setMarkData之后调用 calendarAdapter.notifyDataChanged();
     */
    private void initMarkData() {
        HashMap<String, String> markData = new HashMap<>();
        markData.put("2019-11-17", "0");
        calendarAdapter.setMarkData(markData);
    }
    //以下为点击事件函数
    private void initListener() {
        onSelectDateListener = new OnSelectDateListener() {
            @Override
            public void onSelectDate(final CalendarDate date) {
                Log.e("test","newtest");
                Log.e("sionon",date.month+"");
                Log.e("喵喵喵喵喵喵喵",date.day+"");
                Log.e("siononTest",date.year+"-"+date.month+"-"+date.day);
                int tag=0;
                ArrayList<Massage> sion = new ArrayList<>();
                ListView listView = view.findViewById(R.id.lv_persons);
                for(int i=0;i<test.size();++i){
                    Log.e("sion",test.get(i).getTime());
                    String s=date.year+"-"+date.month+"-"+date.day;
                    if(s.equals(test.get(i).getTime())) {

                        Log.e("sion123", test.get(i).getTime());

                        sion.add(test.get(i));

                        tag=1;

                    }
                }

                CustomAdapter custtomAdapter10 = new CustomAdapter(getContext(), sion, R.layout.list_item_view_layout);
                listView.setAdapter(custtomAdapter10);
                if(tag==0){
                    ListView listView1 = view.findViewById(R.id.lv_persons);
                    ArrayList<Massage> sion1 = new ArrayList<>();
                    CustomAdapter custtomAdapter19 = new CustomAdapter(getContext(), sion1, R.layout.list_item_view_layout);
                    listView1.setAdapter(custtomAdapter19);
                    tag=0;
                }
                refreshClickDate(date);
            }

            @Override
            public void onSelectOtherMonth(int offset) {
                //偏移量 -1表示刷新成上一个月数据 ， 1表示刷新成下一个月数据
                monthPager.selectOtherMonth(offset);
            }
        };
    }


    private void refreshClickDate(CalendarDate date) {
        currentDate = date;
        tvYear.setText(date.getYear() + "年");
        tvMonth.setText(date.getMonth() + "");
    }

    /**
     * 初始化monthPager，MonthPager继承自ViewPager
     *
     * @return void
     */
    private void initMonthPager() {
        monthPager.setAdapter(calendarAdapter);
        monthPager.setCurrentItem(MonthPager.CURRENT_DAY_INDEX);
        monthPager.setPageTransformer(false, new ViewPager.PageTransformer() {
            @Override
            public void transformPage(View page, float position) {
                position = (float) Math.sqrt(1 - Math.abs(position));
                page.setAlpha(position);
            }
        });
        monthPager.addOnPageChangeListener(new MonthPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                mCurrentPage = position;
                currentCalendars = calendarAdapter.getPagers();
                if (currentCalendars.get(position % currentCalendars.size()) != null) {
                    CalendarDate date = currentCalendars.get(position % currentCalendars.size()).getSeedDate();
                    currentDate = date;
                    tvYear.setText(date.getYear() + "年");
                    tvMonth.setText(date.getMonth() + "");
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    public void onClickBackToDayBtn() {
        refreshMonthPager();
    }

    private void refreshMonthPager() {
        CalendarDate today = new CalendarDate();
        calendarAdapter.notifyDataChanged(today);
        tvYear.setText(today.getYear() + "年");
        tvMonth.setText(today.getMonth() + "");
    }

    private void refreshSelectBackground() {
        ThemeDayView themeDayView = new ThemeDayView(context, R.layout.custom_day_focus);
        calendarAdapter.setCustomDayRenderer(themeDayView);
        calendarAdapter.notifyDataSetChanged();
        calendarAdapter.notifyDataChanged(new CalendarDate());
    }
    /**
     * 标记日期函数，传入年，月，日以及标记编号
     * by:sionon
     * @return void
     */
    private void markData(){
        HashMap<String, String> markData = new HashMap<>();
        markData.put("2019-9-10", "0");
        calendarAdapter.setMarkData(markData);
    }
    /**
     * 点击事件处理，获取点击日期，输出TextView,date中的year成员和day成员用于标识点击日期的月，日
     * by:sionon
     * @return void
     */
    private void clickData(){
        onSelectDateListener = new OnSelectDateListener() {
            @Override
            public void onSelectDate(CalendarDate date) {
                refreshClickDate(date);
            }
            @Override
            public void onSelectOtherMonth(int offset) {
                monthPager.selectOtherMonth(offset);
            }
        };
    }
    /**
     * 获取数据库内容,并标记内容
     * by:sionon
     * @return void
     */
    private void  getMassage(){
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/viewdiary?a="+account);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String info = reader.readLine();
                    final List<Massage > texts = new ArrayList<>();
                    try {
                        JSONArray jsonArray = new JSONArray(info);
                        for(int i = 0; i < jsonArray.length();i++){
                            Massage text=new Massage(jsonArray.getJSONObject(i).getString("account"),jsonArray.getJSONObject(i).getString("time"),jsonArray.getJSONObject(i).getString("text"));
                            System.out.println(text.getAccount());
                            texts.add(text);
                        }
                        HashMap<String, String> markData = new HashMap<>();
                        for(int i=0;i<texts.size();++i){
                            markData.put(texts.get(i).getTime(), "0");
                        }
                        calendarAdapter.setMarkData(markData);
                        getMsg(texts);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
    private void getMsg(Object info){
        Message msg = Message.obtain();
        msg.what = 90;
        msg.obj = info;
        handler.sendMessage(msg);}

}
