package com.example.a24168.myapplication.widget.recyclerview;

/**
 * Created by zhiwenyan on 5/25/17.
 * <p>
 * 条目的点击事件
 */

public interface OnItemClickListener {
    void onItemClick(int position);
}
