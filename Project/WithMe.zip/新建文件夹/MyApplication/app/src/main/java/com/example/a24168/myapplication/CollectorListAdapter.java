package com.example.a24168.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.a24168.myapplication.R;
import com.example.a24168.myapplication.cardbean;

import java.util.Date;
import java.util.List;

public class CollectorListAdapter extends BaseAdapter {
    private List<cardbean> listItems;//数据集合
    private LayoutInflater layoutinflater;//视图容器，用来导入布局
    private Context context;
    private int itemLayoutid;
    static class ViewHolder
    {
        private TextView serialNumber;
        private TextView articleNumber;
        private ImageView image;
    }
    public CollectorListAdapter(Context context, List<cardbean> dataSet,int itemLayoutid)
    {
        this.itemLayoutid = itemLayoutid;
        this.listItems = dataSet;
        this.context = context;


    }

    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public Object getItem(int position) {
        return listItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        convertView =  inflater.inflate(itemLayoutid,null);

        TextView textView = convertView.findViewById(R.id.carditem2);
        TextView textView1 = convertView.findViewById(R.id.carditem3);
        String a = listItems.get(position).getText();
        String b = listItems.get(position).getAccount();
        String c = listItems.get(position).getDate();
        ImageView imageView = convertView.findViewById(R.id.carditem1);

        textView.setText(c);
        textView1.setText(a);

        return convertView;
    }
}
