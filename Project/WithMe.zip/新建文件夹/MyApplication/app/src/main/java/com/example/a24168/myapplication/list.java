package com.example.a24168.myapplication;

public class list {
    private String names;
    private String sex;
    private String birthday;
    private String hobby;
    private String Personalsignature;
    private String Image;

    public String getNames() {
        return names;
    }

    public String getSex() {
        return sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getHobby() {
        return hobby;
    }

    public String getPersonalsignature() {
        return Personalsignature;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setPersonalsignature(String personalsignature) {
        Personalsignature = personalsignature;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public list() {

    }
}
