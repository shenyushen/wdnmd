package com.example.a24168.myapplication;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;


public class newclass extends AppCompatActivity implements View.OnClickListener{
    private int i = 0;
    private EditText editText;
    private String date;
    private View inflate;
    private TextView choosePhoto;
    private TextView takePhoto;
    private Dialog dialog;
    private FloatingActionButton button;
    private TimePicker tp;
    private Timezxw time = new Timezxw(0,0,0,0,0,0);
    private DatePicker dp;
    private TextView textView;
    private TextView textView0;
    private TextView textView2;
    private TextView commit;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.time);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textview);


        commit = findViewById(R.id.commit);
        editText = findViewById(R.id.edittext);
        SlideButton slideButton = (SlideButton) findViewById(R.id.slide_button);
        final TextView textView1 = (TextView) findViewById(R.id.zhuangtai);
        slideButton.setOnSlideButtonClickListener(new SlideButton.OnSlideButtonClickListener() {
            @Override
            public void onClicked(boolean isChecked) {
                if (isChecked) {
                    textView1.setText("公开");
                    i = 1;
                    textView1.setTextColor(0xffFDBD19);
                } else {
                    textView1.setText("私密");
                    i = 0;
                    textView1.setTextColor(0xff9d06e7);

                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show(v);
            }
        });
        commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textView.getText().toString() == null || textView.getText().toString().equals("")) {
                    Toast.makeText(newclass.this, "请添加时间", Toast.LENGTH_SHORT).show();
                } else {
                    new Thread() {
                        @Override
                        public void run() {
                            try {
                                String b;
                                if (editText.getText().toString() != null) {
                                    b = editText.getText().toString();
                                } else {
                                    b = "";
                                }

                                URL url = new URL(getResources().getString(R.string.ip)+"/Adddiaryzxw?a=" + date + "&b=" + b + "&c=" + account + "&d=" +i);
                                URLConnection conn = url.openConnection();
                                InputStream in = conn.getInputStream();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();

                    Toast.makeText(newclass.this, "提交成功", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(newclass.this, MainActivity.class);
                    startActivity(intent);
                }


            }
        });
    }


    public void show(View view){
        dialog = new Dialog(this,R.style.ActionSheetDialogStyle);
        //填充对话框的布局
        inflate = LayoutInflater.from(this).inflate(R.layout.duihuakuang, null);
        //初始化控件

        tp = (TimePicker)inflate.findViewById(R.id.tp);
        dp = (DatePicker) inflate.findViewById(R.id.dp);
        tp.setIs24HourView(true);
        /*tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                textView.setText(hourOfDay+" : "+minute);
            }
        });*/

        Calendar cal=Calendar.getInstance();
        int year=cal.get(Calendar.YEAR);
        int month=cal.get(Calendar.MONTH)+1;//特殊的是Calendar中月份从0开始计数，所以加1得到常规月份
        int day=cal.get(Calendar.DAY_OF_MONTH);


        dp.init(year,month,day, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //textView0.setText(year+" : "+monthOfYear+1+" : "+dayOfMonth);
            }
        });

        //更改宽度
        LinearLayout dpContainer = (LinearLayout)dp.getChildAt(0)   ;   // LinearLayout
        LinearLayout dpSpinner = (LinearLayout)dpContainer.getChildAt(0);       // 0 : LinearLayout; 1 : CalendarView
        for(int i = 0; i < dpSpinner.getChildCount(); i ++) {
            NumberPicker numPicker = (NumberPicker)dpSpinner.getChildAt(i);     // 0-2 : NumberPicker
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(180, LinearLayout.LayoutParams.WRAP_CONTENT);
            params1.leftMargin = 0;
            params1.rightMargin = 30;
            numPicker.setLayoutParams(params1);
        }
        resizePicker(tp);
        choosePhoto = (TextView) inflate.findViewById(R.id.choosePhoto);
        takePhoto = (TextView) inflate.findViewById(R.id.takePhoto);
        choosePhoto.setOnClickListener(this);
        takePhoto.setOnClickListener(this);
        //将布局设置给Dialog
        dialog.setContentView(inflate);
        //获取当前Activity所在的窗体
        Window dialogWindow = dialog.getWindow();
        //设置Dialog从窗体底部弹出
        dialogWindow.setGravity( Gravity.BOTTOM);
        //获得窗体的属性
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.y = 20;//设置Dialog距离底部的距离
        //    将属性设置给窗体
        dialogWindow.setAttributes(lp);
        dialog.show();//显示对话框
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.takePhoto://点击确认
                time.setMinute(tp.getCurrentMinute());
                time.setHour(tp.getCurrentHour());
                time.setYear(dp.getYear());
                time.setMonth(dp.getMonth()+1);
                time.setDay(dp.getDayOfMonth());
                date = time.getYear()+"-"+time.getMonth()+"-"+time.getDay()+" "+time.getHour()+":"+time.getMinute()+":"+time.getSecond();
                textView.setText(date);
                break;
            case R.id.choosePhoto:
                break;
        }
        dialog.dismiss();
    }

    //Datepicket修改宽度
    private void resizePicker(FrameLayout tp){        //DatePicker和TimePicker继承自FrameLayout
        List<NumberPicker> npList = findNumberPicker(tp);  //找到组成的NumberPicker
        for(NumberPicker np:npList){
            resizeNumberPicker(np);      //调整每个NumberPicker的宽度
        }
    }
    /**
     * 得到viewGroup 里面的numberpicker组件
     * */
    private List<NumberPicker> findNumberPicker(ViewGroup viewGroup) {
        List<NumberPicker> npList = new ArrayList<NumberPicker>();
        View child = null;
        if(null != viewGroup){
            for(int i=0;i<viewGroup.getChildCount();i++){
                child = viewGroup.getChildAt(i);
                if(child instanceof NumberPicker){
                    npList.add((NumberPicker)child);
                }else if(child instanceof LinearLayout){
                    List<NumberPicker> result = findNumberPicker((ViewGroup) child);
                    if(result.size()>0){
                        return result;
                    }
                }
            }
        }
        return npList;
    }

    /**
     * 调整numberpicker大小
     * */
    private void resizeNumberPicker(NumberPicker np){
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(10,0,10,0);
        np.setLayoutParams(params);
    }
}
