package com.example.a24168.myapplication;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;


import static com.example.a24168.myapplication.ForFuture.dat;
import static com.example.a24168.myapplication.ForFuture.letterAdapter;
import static com.example.a24168.myapplication.ForFuture.listView;
import static com.example.a24168.myapplication.ForFuture.asdfghj;


public  class WriteLetter extends AppCompatActivity implements View.OnClickListener{
    private View inflate;
    private TextView cancel,define1,sss;
    private Dialog dialog;
    private DatePicker dp;
    Context context;
    private Handler handler = new Handler();
    Button dateText;
    ImageButton btn_quit,btn_confirm;
    EditText editText;
    String desc,desc2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.writeletter);
        dateText=findViewById(R.id.dateText);

        editText=findViewById(R.id.add_content);
        btn_quit=findViewById(R.id.btn_quit);
        btn_confirm=findViewById(R.id.btn_confirm);
        sss=findViewById(R.id.sss);

        dateText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show(v);
            }
        });

        btn_quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {//创建子线程
                    @Override
                    public void run() {
                        try {
                            final String datetime=desc2;
                            final String letter=editText.getText().toString();
                            URL url = new URL("http://"+getResources().getString(R.string.ipaddress)+":8080/CakeEvent/Insert?user=admin&letter="+letter+"&datetime="+datetime);
                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                            httpURLConnection.setRequestMethod("GET");
                            httpURLConnection.setConnectTimeout(8000);
                            httpURLConnection.setReadTimeout(8000);
                            InputStream in = httpURLConnection.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    String [] as={datetime,letter};
                                    dat.add(as);
                                    letterAdapter = new LetterAdapter(asdfghj,dat, R.layout.forfuture_listview);
                                    listView.setAdapter(letterAdapter);;

                                }
                            });
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                finish();
            }
        });
    }

    public void show(View view){
        dialog = new Dialog(this,R.style.ActionSheetDialogStyle);
        //填充对话框的布局
        inflate = LayoutInflater.from(this).inflate(R.layout.writeletter_datepicker, null);
        //初始化控件
        dp = (DatePicker) inflate.findViewById(R.id.dp);
        Calendar cal=Calendar.getInstance();
        int year=cal.get(Calendar.YEAR);
        int month=cal.get(Calendar.MONTH)+1;//特殊的是Calendar中月份从0开始计数，所以加1得到常规月份
        int day=cal.get(Calendar.DAY_OF_MONTH);
        dp.init(year,month,day, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int month, int dayOfMonth) {
                desc=String.format("将要寄往%d年%02d月%02d日",year,month+1,dayOfMonth);
                desc2=String.format("%d%02d%02d",year,month+1,dayOfMonth);
                sss.setText(desc);
            }
        });
        //更改宽度
        LinearLayout dpContainer = (LinearLayout)dp.getChildAt(0)   ;
        LinearLayout dpSpinner = (LinearLayout)dpContainer.getChildAt(0);
        for(int i = 0; i < dpSpinner.getChildCount(); i ++) {
            NumberPicker numPicker = (NumberPicker)dpSpinner.getChildAt(i);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(299, LinearLayout.LayoutParams.WRAP_CONTENT);

            params1.setMargins(10,10,10,5);
            numPicker.setLayoutParams(params1);
        }
        cancel = (TextView) inflate.findViewById(R.id.cancel);
        define1 = (TextView) inflate.findViewById(R.id.define1);
        cancel.setOnClickListener(this);
        define1.setOnClickListener(this);
        //将布局设置给Dialog
        dialog.setContentView(inflate);
        //获取当前Activity所在的窗体
        Window dialogWindow = dialog.getWindow();
        //设置Dialog从窗体底部弹出
        dialogWindow.setGravity( Gravity.BOTTOM);
        //获得窗体的属性
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.y = 50;//设置Dialog距离底部的距离
        //    将属性设置给窗体
        dialogWindow.setAttributes(lp);
        dialog.show();//显示对话框
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.define1:
                break;
            case R.id.cancel:
                break;
        }
        dialog.dismiss();
    }

}
