package com.example.a24168.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.example.a24168.myapplication.Message_details.account;
/*这个页面时朋友圈的adpater*/
public class messgae_Adapter extends BaseAdapter {
    private int itemLayoutId,i,pos=0;
    private Context context;
    private List<message_user> message_userList=new ArrayList<message_user>();
    public messgae_Adapter(Context context, List<message_user> message_userList, int itemLayoutId) {
        this.context = context;
        this.message_userList = message_userList;
        this.itemLayoutId = itemLayoutId;
    }
    @Override
    public int getCount() {
        if (null != message_userList) {
            return message_userList.size();
        }else {
            return 0;
        }
    }

    @Override
    public Object getItem(int position) {
        if (null != message_userList) {
            return message_userList.get(position);
        }else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        int[]a={R.id.message_image1,R.id.message_image2,R.id.message_image3,R.id.message_image4,R.id.message_image5,R.id.message_image6,R.id.message_image7,R.id.message_image8,R.id.message_image9};
        if (null == convertView) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(itemLayoutId, null);
        }
        //获取每一个item中各种视图控件的对象
        ImageView message_userimage = convertView.findViewById(R.id.message_userimage);
        TextView name = convertView.findViewById(R.id.message_name);
        TextView time = convertView.findViewById(R.id.message_time);
        TextView talk = convertView.findViewById(R.id.message_talk);
        TextView comment = convertView.findViewById(R.id.comment);
        ImageView message_imageall;
        for(int innt=0;innt<9;innt++){
            message_imageall = convertView.findViewById(a[innt]);
            message_imageall.setVisibility(View.GONE);
        }
        Glide.with(context)
                .load("http://"+context.getResources().getString(R.string.ip)+":8080/17_upload/upload/"+message_userList.get(position).getUser_image())
                .apply(RequestOptions.circleCropTransform())
                .into(message_userimage);


        message_user msgUser = message_userList.get(position);
        if(!message_userList.get(position).getImages()[0].equals("null")){
            if(1<=message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=3){pos=3;}
            if(3<message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=6){pos=6;}
            if(6<message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=9){pos=9;}
            for(i=0;i<message_userList.get(position).getImages().length;i++){
                message_imageall = convertView.findViewById(a[i]);
                message_imageall.setVisibility(View.VISIBLE);
                RequestOptions requestOptions = new RequestOptions().centerCrop();
                Glide.with(context)
                        .load("http://"+context.getResources().getString(R.string.ip)+":8080/17_upload/upload/"+message_userList.get(position).getImages()[i])
                        /*.apply(requestOptions)*/
                        .into(message_imageall);
                int n=i;
                        message_imageall.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent in=new Intent(context,lookimages.class);
                                in.putExtra("imgs",message_userList.get(position).getImages());
                                in.putExtra("position",n);
                                Log.e("ssssss",n+"");
                                context.startActivity(in);
                            }
                        });
            }
            for(i=message_userList.get(position).getImages().length;i<pos;i++){
                message_imageall = convertView.findViewById(a[i]);
                message_imageall.setVisibility(View.VISIBLE);
            }
        }
        comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context,Message_details.class);
                i.putExtra("id",message_userList.get(position).getId());
                i.putExtra("position",position);
                context.startActivity(i);
            }
        });
        message_userimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lookonesmessage();
            }
        });
        name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lookonesmessage();
            }
        });
        name.setText(message_userList.get(position).getAccount());
        time.setText(message_userList.get(position).getTime());
        talk.setText(message_userList.get(position).getText());
        return convertView;
    }
    public void lookonesmessage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //1,找水源--创建URL
                    URL url = new URL("http://"+context.getResources().getString(R.string.ip)+":8080/testd/message?que=lookonesmessage&&account="+account);//放网站
                    //2,开水闸--openConnection
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    //3，建管道--InputStream
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    InputStream in = httpURLConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String [] str=line.split(" ");
                        Intent i=new Intent(context,lookonesmessage.class);
                        i.putExtra("message",str);
                        context.startActivity(i);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static class message_user {
        private String account;
        private String user_image;
        private String time;
        private String text;
        private String id;
        private String[] images;
    public  message_user(String user_image,String account,String time,String text,String id,String [] images){
        this.user_image=user_image;
        this.account=account;
        this.time=time;
        this.text=text;
        this.id=id;
        this.images=images;
    }
        public String getUser_image() {
            return user_image;
        }
        public void setUser_image(String user_image) {
            this.user_image = user_image;
        }
        public String[] getImages() {
            return images;
        }
        public void setImages(String[] images) {
            this.images = images;
        }
        public String getAccount() {
            return account;
        }
        public void setAccount(String account) {
            this.account = account;
        }
        public String getTime() {
            return time;
        }
        public void setTime(String time) {
            this.time = time;
        }
        public String getText() {
            return text;
        }
        public void setText(String text) {
            this.text = text;
        }
        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
    }
}

