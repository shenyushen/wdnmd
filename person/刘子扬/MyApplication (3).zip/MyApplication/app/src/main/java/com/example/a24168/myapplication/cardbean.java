package com.example.a24168.myapplication;

import java.util.Date;

public class cardbean {
    private String account;
    private String date;
    private String text;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }



    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public cardbean(String account, String text,String date) {
        this.account = account;
        this.date = date;
        this.text = text;
    }
    public cardbean(){

    }
}
