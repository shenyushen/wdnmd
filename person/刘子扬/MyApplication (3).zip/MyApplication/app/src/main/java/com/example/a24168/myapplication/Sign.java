package com.example.a24168.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import static com.example.a24168.myapplication.fragment.MessageFragment.account;


public class Sign extends AppCompatActivity {

    private EditText ed_account;
    private EditText ed_pass;
    private Button bt_sign;
    private Button bt_post;
    private int q1;
    private void getViews(){
        ed_account=findViewById(R.id.ed_account);
        ed_pass=findViewById(R.id.ed_pass);
        bt_post=findViewById(R.id.bt_post);
        bt_sign=findViewById(R.id.bt_sign);
    }
    private void check(String a,String b){
        q1=0;
        final String c = a;
        final String d = b;
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(getResources().getString(R.string.ip)+"/viewuser");
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String info = reader.readLine();
                    try {
                        JSONArray jsonArray = new JSONArray(info);
                        for(int i = 0; i < jsonArray.length();i++){
                            if(jsonArray.getJSONObject(i).getString("account").equals(c)&&jsonArray.getJSONObject(i).getString("password").equals(d)){
                                Intent intent = new Intent(Sign.this,MainActivity.class);
                                String account1=jsonArray.getJSONObject(i).getString("account");
                                account=account1;
                                startActivity(intent);
                                q1=1;
                                break;
                            }
                            System.out.println(jsonArray.getJSONObject(i).getString("account")+"        "+jsonArray.getJSONObject(i).getString("password"));
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_layout);
        if (Build.VERSION.SDK_INT >= 23) {
            int REQUEST_CODE_CONTACT = 101;
            String[] permissions = {Manifest.permission.INTERNET};
            //验证是否许可权限
            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    //申请权限
                    this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                    return;
                }
            }
        }
        getViews();
        bt_sign.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                check(ed_account.getText().toString(),ed_pass.getText().toString());
            }
        });

        bt_post.setOnClickListener(new View.OnClickListener() {
            //创建监听器
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Sign.this,Post.class);
                startActivity(i);
            }
        });
    }
}
