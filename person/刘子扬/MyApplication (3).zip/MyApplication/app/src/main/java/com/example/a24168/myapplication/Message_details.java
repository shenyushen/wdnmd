package com.example.a24168.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import static com.example.a24168.myapplication.fragment.MessageFragment.account;
import static com.example.a24168.myapplication.fragment.MessageFragment.message_userList;
/*这个页面是查看详细说说的页面，调用message_adpateri借鉴的部分函数*/

public class Message_details extends AppCompatActivity {
    public int i;
    public Handler handler=new Handler();
    public ArrayList<String[]> list;
    public Intent intent;
    public int position;
    public String id;
    public ListView listView;
    public Context context=this;
    private Button button;
    private EditText editText;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.messagedetaileslayout);
        listView=findViewById(R.id.message_dalies);
        button=findViewById(R.id.button_people);
        editText=findViewById(R.id.comment_people);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String comment=editText.getText().toString().trim();
                            //1,找水源--创建URL
                            if(!comment.equals("")){
                            Log.e("sss",comment.equals("")+"");
                            URL url = new URL(getResources().getString(R.string.ip)+"/message?que=addcomment&&id="+id+"&&account="+account+"&&text="+comment);//放网站
                            //2,开水闸--openConnection
                            Log.e("url",url.toString());
                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                            //3，建管道--InputStream
                            httpURLConnection.setRequestMethod("GET");
                            httpURLConnection.setConnectTimeout(8000);
                            httpURLConnection.setReadTimeout(8000);
                            InputStream in = httpURLConnection.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                            String line;
                            while ((line = reader.readLine()) != null) {
                                if(line.equals("1")){
                                    handler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(context,"评论成功",Toast.LENGTH_LONG).show();
                                            editText.setText("");
                                            editText.setHint("评论");
                                            message_dalies();
                                        }
                                    });
                                }
                            }}
                            else{
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(context,"评论不能为空",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        init();
    }
    public void init(){
        intent=getIntent();
        int pos=0;
        position=intent.getIntExtra("position",0);
        id=intent.getStringExtra("id");
        ImageView message_userimage = findViewById(R.id.message_userimage);
        TextView name = findViewById(R.id.message_name);
        TextView time = findViewById(R.id.message_time);
        TextView talk = findViewById(R.id.message_talk);
        Glide.with(context)
                .load(context.getResources().getString(R.string.ip)+"/upload/"+message_userList.get(position).getUser_image())
                .apply(RequestOptions.circleCropTransform())
                .into(message_userimage);
        int[]a={R.id.message_image1,R.id.message_image2,R.id.message_image3,R.id.message_image4,R.id.message_image5,R.id.message_image6,R.id.message_image7,R.id.message_image8,R.id.message_image9};
        if(!message_userList.get(position).getImages()[0].equals("null")){
            if(1<=message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=3){pos=3;}
            if(3<message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=6){pos=6;}
            if(6<message_userList.get(position).getImages().length && message_userList.get(position).getImages().length<=9){pos=9;}
            for(i=0;i<message_userList.get(position).getImages().length;i++){
                ImageView message_imageall = findViewById(a[i]);
                message_imageall.setVisibility(View.VISIBLE);
                RequestOptions requestOptions = new RequestOptions().centerCrop();
                Glide.with(context)
                        .load(context.getResources().getString(R.string.ip)+"/upload/"+message_userList.get(position).getImages()[i])
                        /*.apply(requestOptions)*/
                        .into(message_imageall);
                int n=i;
                message_imageall.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent in=new Intent(context,lookimages.class);
                        in.putExtra("imgs",message_userList.get(position).getImages());
                        in.putExtra("position",n);
                        Log.e("ssssss",n+"");
                        context.startActivity(in);
                    }
                });
            }
            for(i=message_userList.get(position).getImages().length;i<pos;i++){
                ImageView message_imageall = findViewById(a[i]);
                message_imageall.setVisibility(View.VISIBLE);
            }
        }
        message_userimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lookonesmessage();
            }
        });
        name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lookonesmessage();
            }
        });
        name.setText(message_userList.get(position).getAccount());
        time.setText(message_userList.get(position).getTime());
        talk.setText(message_userList.get(position).getText());
        message_dalies();
    }
    public void lookonesmessage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.e("bb",message_userList.get(position).getAccount());
                    //1,找水源--创建URL
                    URL url = new URL(context.getResources().getString(R.string.ip)+"/message?que=lookonesmessage&&account="+message_userList.get(position).getAccount());//放网站
                    //2,开水闸--openConnection
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    //3，建管道--InputStream
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    InputStream in = httpURLConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String [] str=line.split(" ");
                        Intent i=new Intent(context,lookonesmessage.class);
                        i.putExtra("message",str);
                        context.startActivity(i);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void message_dalies() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    list=new ArrayList<String[]>();
                    //1,找水源--创建URL
                    URL url = new URL(getResources().getString(R.string.ip)+"/message?que=lookdetailsmessage&&id="+id+"");//放网站
                    //2,开水闸--openConnection
                    Log.e("url",url.toString());
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    //3，建管道--InputStream
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    InputStream in = httpURLConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String [] str=line.split(" ");
                       list.add(str);
                    }
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Message_dalies_adpater listAdapter=new Message_dalies_adpater(context,list,R.layout.messagr_dalies);
                            listView.setAdapter(listAdapter);
                        }
                    });

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
