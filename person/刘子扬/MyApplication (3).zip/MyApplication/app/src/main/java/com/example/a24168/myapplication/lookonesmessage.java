package com.example.a24168.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
/*此页面时查看个人信息页的页面*/
public class lookonesmessage extends AppCompatActivity {
    private Intent intent;
    private String[] strings;
    private TextView account;
    private TextView name;
    private TextView sex;
    private TextView hobby;
    private TextView birthday;
    private TextView Personalsignature;
    private ImageView message_userimage;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onesmessage);
        init();
    }
    public void init(){
        intent=getIntent();
        strings=intent.getStringArrayExtra("message");
        account=findViewById(R.id.message_account);
        name=findViewById(R.id.message_name);
        message_userimage = findViewById(R.id.message_userimage);
        sex=findViewById(R.id.message_sex);
        hobby=findViewById(R.id.message_hobby);
        birthday=findViewById(R.id.message_birthday);
        Personalsignature=findViewById(R.id.message_Personalsignature);
        account.setText("账号："+strings[1]);
        name.setText(strings[2]);
        sex.setText(strings[3]);
        hobby.setText(strings[5]);
        birthday.setText(strings[4]);
        Personalsignature.setText(strings[6]);
        Glide.with(this)
                .load(getResources().getString(R.string.ip)+"/upload/"+strings[0])
                .apply(RequestOptions.circleCropTransform())
                .into(message_userimage);
    }

}
