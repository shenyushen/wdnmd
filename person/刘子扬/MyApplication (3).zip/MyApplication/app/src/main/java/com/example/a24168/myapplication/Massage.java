package com.example.a24168.myapplication;
/**
 * @Description:
 * @author by SIONON
 * @date 2019/12/4
 * @version V1.0
 */
public class Massage {
    private String account;
    private String time;
    private String text;

    public Massage(String account, String time, String text) {
        this.account = account;
        this.time = time;
        this.text = text;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public String getAccount() {
        return account;
    }

    public String getTime() {
        return time;
    }
}
