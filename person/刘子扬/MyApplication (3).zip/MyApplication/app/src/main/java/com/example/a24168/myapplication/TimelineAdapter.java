package com.example.a24168.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.a24168.myapplication.R;

import java.util.List;
import java.util.Map;

public class TimelineAdapter extends BaseAdapter {
    private Context context;
    private List<Map<String, Object>> list;
    private LayoutInflater inflater;

    public TimelineAdapter(Context context, List<Map<String, Object>> list) {
        super();
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {

        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;

        if (convertView == null) {
            inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(R.layout.listview_item, null);
            viewHolder = new ViewHolder();


            viewHolder.title = (TextView) convertView.findViewById(R.id.title);
            viewHolder.show_time = (TextView) convertView.findViewById(R.id.show_time);
            viewHolder.image=(ImageView) convertView.findViewById(R.id.image);

            viewHolder.listView = convertView.findViewById(R.id.listview);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        String titleStr = list.get(position).get("title").toString();
        String timeStr = list.get(position).get("show_time").toString();
        viewHolder.title.setText(titleStr);
        viewHolder.show_time.setText(timeStr);


        return convertView;
    }

    static class ViewHolder {
        public TextView year;
        public TextView month;
        public ImageView image;
        public TextView title;
        View view_2;

        public ListView listView;
        public  TextView show_time;
    }
}
