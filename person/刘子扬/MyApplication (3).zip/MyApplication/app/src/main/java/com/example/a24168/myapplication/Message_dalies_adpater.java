package com.example.a24168.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;
/*此页面时详细说说的adpater*/
public class    Message_dalies_adpater extends BaseAdapter {
    private int itemLayoutId;
    private Context context;
    private ImageView imageView;
    private TextView textView;
    private TextView textView1;
    private TextView textView2;
    private List<String[]> message_daliesimage;
    public Message_dalies_adpater(Context context, List<String[]> message_daliesimage, int itemLayoutId) {
        this.context = context;
        this.message_daliesimage = message_daliesimage;
        this.itemLayoutId = itemLayoutId;
    }

    @Override
    public int getCount() {
        if (null != message_daliesimage) {
            return message_daliesimage.size();
        }else {
            return 0;
        }
    }

    @Override
    public Object getItem(int position) {
        if (null != message_daliesimage) {
            return message_daliesimage.get(position);
        }else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (null == convertView) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(itemLayoutId, null);
        }
        imageView=convertView.findViewById(R.id.message_userimage);
        textView=convertView.findViewById(R.id.message_name);
        textView1=convertView.findViewById(R.id.message_text);
        textView2=convertView.findViewById(R.id.message_time);
        Glide.with(context)
                .load(context.getResources().getString(R.string.ip)+"/upload/"+message_daliesimage.get(position)[0])
                .apply(RequestOptions.circleCropTransform())
                .into(imageView);
        textView.setText(message_daliesimage.get(position)[1]);
        textView1.setText(message_daliesimage.get(position)[2]);
        textView2.setText(message_daliesimage.get(position)[3]);
        return convertView;
    }
}
